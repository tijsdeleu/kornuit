<div class="mainmenu">
  <ul>
    <li><a href="index.php">home</a></li>
    <li><a href="index.php?page=visie">visie</a></li>
    <li><a href="index.php?page=historiek">historiek</a></li>
    <li><a href="index.php?page=galerij">galerij</a></li>
    <li><a href="index.php?page=kinderdagverblijf">kinderdagverblijf</a></li>
    <li><a href="index.php?page=middagopvang">middagopvang</a></li>
    <li><a href="index.php?page=ibo">IBO</a></li>
    <li><a href="index.php?page=contact">contact</a></li>
  </ul>
</div>
