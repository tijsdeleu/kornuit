<?php

class galerijimage 
  {
  
  }