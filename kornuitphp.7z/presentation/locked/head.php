  <head>
    <script src="js/lightbox/dist/js/lightbox-plus-jquery.js"></script>
    <link rel="stylesheet" type="text/css" href="css/layout.css">
    <link rel="stylesheet" type="text/css" href="js/lightbox/src/css/lightbox.css">
    <meta charset="UTF-8">
    <title></title>
  </head>