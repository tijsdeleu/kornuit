<?php

class DBConfig
  {
  public static $DB_CONNSTRING = "mysql:host=localhost;dbname=kornuitsymfony";
  public static $DB_USERNAME = "kornuit";
  public static $DB_PASSWORD = "kornuit";
  }